var i = 1;
while (i <= 120) {
    if (i % 2 != 0) {
        console.log("Saya orang ke-" + i);
    }
    i++;
}