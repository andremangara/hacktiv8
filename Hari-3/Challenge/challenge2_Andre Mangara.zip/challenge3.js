var i = 1;
while (i <= 120) {
    console.log("Saya orang ke-" + i);
    i++;
}